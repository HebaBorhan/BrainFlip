from .login import login_bp
from .game import game_bp
from .leaderboard import leaderboard_bp
from .dashboard import dashboard_bp
from .registration import register_bp